import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import path from 'node:path';
export default defineConfig({base:'./',plugins:[react(),tailwindcss()],resolve:{alias:{'@':path.resolve(import.meta.dirname,'src')}},build:{outDir:process.env.PATCHWORK_LIBRARY_OUTPUT || 'dist',emptyOutDir:true}});
