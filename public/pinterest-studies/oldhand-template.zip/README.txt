Oldhand reference study

Extract all files and open index.html in a modern browser. Edit the HTML, CSS and JavaScript to customize the hero. The blue halftone artwork was generated with ChatGPT Images. This is an approximation of the supplied reference video. Links and notes are illustrative.
