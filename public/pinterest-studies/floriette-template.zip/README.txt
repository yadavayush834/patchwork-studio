Botanical Portfolio hero
Extract all files and open index.html. Edit the HTML labels and CSS tokens in index.html. The calligraphic title is editable text using Great Vibes; the botanical art and paper texture were generated with ChatGPT Images. GSAP is included locally. See DESIGN-GUIDE.md for layout, typography and future expansion guidance. No dependencies or build step required.
