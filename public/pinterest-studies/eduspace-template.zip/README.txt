Education dashboard reference

Extract all files and open index.html in a modern browser. Edit the HTML, CSS, and sample data inside index.html to customize the dashboard. The avatar sheet was generated with ChatGPT Images. Course content is demonstrative. Enrollment, lesson milestones, schedule and profile are stored in your browser. See DESIGN-GUIDE.md for visual patterns and expansion guidance.
