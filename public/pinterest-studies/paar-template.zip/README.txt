Paar reference study

Extract all files and open index.html in a modern browser. Edit the HTML, CSS and JavaScript in index.html to customize the page. Pixel artwork is rendered locally using canvas. The design is an approximation of the supplied video.
