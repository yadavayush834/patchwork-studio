Hearthstone Roasters — video-inspired coffee poster

Extract all files and open index.html in a modern browser. Scroll vertically through the hero. Edit the HTML and CSS to customize. The bottle and landscape are AI-generated; the bottle is a flat image and its label is not editable text. See DESIGN-GUIDE.md and the included licenses.