Citylines — editable website template

1. Extract the entire ZIP into one folder.
2. Open index.html in a modern browser. The artwork and animation work locally.
3. Edit index.html to change the words, colours, layout and train animation.
4. Keep citylines-city.png beside index.html, or update its image path.
5. Upload both files to any static website host to publish your copy.

No installation, account, API key, or Patchwork connection is needed.
All CSS and animation code is included in index.html. The page respects your device's reduced-motion preference. Send a train restarts the train journey.

This package contains the complete current Citylines hero study. Navigation links are demonstration anchors, not additional pages or an app download. The design is a recreation from a supplied video; the city artwork was generated with ChatGPT Images. It is not the original reference source.
